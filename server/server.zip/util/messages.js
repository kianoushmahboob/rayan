module.exports = {
    loginWrongUsernameOrPassword: 'کاربری با این مشخصات  وجود ندارد',
    notAuthenticated: 'دسترسی شما به پایان رسیده است,لطفا دوباره وارد سایت شوید',
    databaseNotConnected: 'اتصال با پایگاه داده با اشکال مواجه شده است',
    databaseIntenalError: 'خطایی در پایگاه داده رخ داده است',
    successActiveUser: 'حساب کاربری شما با موفقیت فعال شد',
    faildActiveUser: 'کد فعال سازی اشتباه میبیاشد',
    isNotUser: 'شما اجازه دسترسی به این بخش ندارید',


}