module.exports = {
    origin: process.env.CLIENT_BASE_URL,
    optonsSuccessStatus: 200
}